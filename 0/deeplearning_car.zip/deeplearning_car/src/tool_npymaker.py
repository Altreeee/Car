import select
from ctypes import *
import struct, array

from sys import argv
import multiprocessing
import time
import getopt
import os

import cv2
import numpy as np
import time


path = os.path.split(os.path.realpath(__file__))[0]+"/.."
opts,args = getopt.getopt(argv[1:],'-h',['vels=','output=','serial=','camera='])
output_data = multiprocessing.Array("b",range(50))#output_data
Speed = multiprocessing.Array("i",range(2))#speed and angle (int)
camera = multiprocessing.Array("b",range(50))#camera
serial = multiprocessing.Array("b",range(50))#serial

output_data.value = "data"
Speed[0]  = 1545
Speed[1]  = 1500
camera.value = "/dev/video0"
serial.value = "/dev/ttyACM0"



angledata = []
data = []
file = open(path+"/data/"+ output_data.value+".txt","r")
for line in file.readlines():
    line = line.strip('\n')
    angledata.append(int(line)) #遍历文本文件的每一行，将每行数据转换为整数，添加到angledata列表中
angle = np.array(angledata) #将angledata列表转换为numpy数组angle
np.save(path+"/data/"+ output_data.value+".npy", angle,False)
file.close()