# -*- coding:utf-8 -*-
"""

run image---->angle

get data from camera:/dev/video0   

params:vels=1535

put image to serial :/dev/ttACM0


"""

import v4l2capture
import sys, select, termios, tty
import os
import time
import threading
from ctypes import *
import numpy as np
import cv2 
from sys import argv


import paddle.fluid as fluid
from PIL import Image
import getopt
from detect import infer

#script,vels,save_path= argv

path = os.path.split(os.path.realpath(__file__))[0]+"/.."
opts,args = getopt.getopt(argv[1:],'-hH',['save_path=','vels=','camera='])


camera = "/dev/video0"
save_path = 'model_infer'
vels  = 1545    #速度

for opt_name,opt_value in opts:
    if opt_name in ('-h','-H'):
        print("python3 Auto_Driver.py --save_path=%s  --vels=%d --camera=%s "%(save_path , vels , camera))
        exit()
        
    if opt_name in ('--save_path'):
        save_path = opt_value

    if opt_name in ('--vels'):
       vels = int(opt_value)
       
    if opt_name in ('--camera'):
       camera = opt_value


#def load_image(cap):

#    lower_hsv = np.array([156, 43, 46])
#    upper_hsv = np.array([180, 255, 255])
#    lower_hsv1 = np.array([0, 43, 46])
#    upper_hsv1 = np.array([10, 255, 255])
#    ref, frame = cap.read()


#    hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)   
#    mask0 = cv2.inRange(hsv, lowerb=lower_hsv, upperb=upper_hsv)
#    mask1 = cv2.inRange(hsv, lowerb=lower_hsv1, upperb=upper_hsv1)
#    mask = mask0 + mask1
#    img = Image.fromarray(mask)
#    img = img.resize((120, 120), Image.ANTIALIAS)
#    img = np.array(img).astype(np.float32)
#    img = cv2.cvtColor(img, cv2.COLOR_GRAY2BGR)
#    img = img.transpose((2, 0, 1))
#    img = img[(2, 1, 0), :, :] / 255.0
#    img = np.expand_dims(img, axis=0)
#    return img


def dataset(video): 
#将视频中特定颜色范围的物体提取出来，然后将其处理成神经网络输入所需的格式。

    lower_hsv = np.array([25,75,190])   #颜色下限
    upper_hsv = np.array([40, 255, 255])    #颜色上限

    select.select((video,), (), ())  #等待数据可读取    
    image_data = video.read_and_queue() #获取图像数据
    
    frame = cv2.imdecode(np.frombuffer(image_data, dtype=np.uint8), cv2.IMREAD_COLOR)
    #将二进制图像数据解码为图像帧，使用 OpenCV 中的 imdecode 函数。这里使用的颜色模式是 cv2.IMREAD_COLOR，表示图像以彩色模式加载。
    hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
    #将 BGR 格式的图像转换为 HSV 色彩空间。
    mask0 = cv2.inRange(hsv, lowerb=lower_hsv, upperb=upper_hsv)
    #根据之前定义的颜色范围创建一个二值掩码 mask0，标识在颜色范围内的区域。
    #mask1 = cv2.inRange(hsv, lowerb=lower_hsv1, upperb=upper_hsv1)
    mask = mask0 #+ mask1


    img = Image.fromarray(mask)
    #使用 PIL 库将 Numpy 数组转换为图像对象。
    img = img.resize((120, 120), Image.ANTIALIAS)
    #将图像大小调整为 (120, 120)。
    img = np.array(img).astype(np.float32)
    #将图像转换为 Numpy 数组，并将数据类型转换为 float32。
    img = cv2.cvtColor(img, cv2.COLOR_GRAY2BGR)
    #将灰度图像转换为 BGR 彩色图像。
    img = img.transpose((2, 0, 1))
    img = img[(2, 1, 0), :, :] / 255.0
    img = np.expand_dims(img, axis=0)   
    return img

if __name__ == "__main__":
    cout = 0
    save_path  = path + "/model/" + save_path
    
    
    #初始化并配置视频设备，准备好捕获摄像头的视频流。
    video = v4l2capture.Video_device(camera)
    video.set_format(424,240, fourcc='MJPG')
    video.create_buffers(1)
    video.queue_all_buffers()
    video.start()
   
    
    #初始化 PaddlePaddle 环境，加载预训练的推理模型，并准备执行环境，以便后续进行模型推理。模型加载后，你可以使用 exe.run() 方法在输入数据上运行推理程序，获取模型的输出结果。
    place = fluid.CPUPlace()
    exe = fluid.Executor(place)
    exe.run(fluid.default_startup_program())
    [infer_program, feeded_var_names, target_var] = fluid.io.load_inference_model(dirname=save_path, executor=exe)
    #从指定的目录（save_path）中加载推理模型


    #vel = int(vels)
    lib_path = path + "/lib" + "/libart_driver.so"
    so = cdll.LoadLibrary
    lib = so(lib_path)
    car = "/dev/ttyACM0"

    if (lib.art_racecar_init(38400, car.encode("utf-8")) < 0):
    #初始化与车辆的通信
        raise
        pass
    try:
        while 1:
            cam = cv2.VideoCapture(1)
            #使用 OpenCV 打开编号为 1 的摄像头，创建了一个 VideoCapture 对象 cam。
            ret,frame = cam.read()
            #读取摄像头的一帧图像，并将其存储在变量 frame 中。
            res=cv2.resize(frame,(224,224),interpolation=cv2.INTER_CUBIC)
            #将图像大小调整为 (224, 224)。
            cv2.imwrite("1.jpg",res)
            #将调整大小后的图像保存为文件 "1.jpg"。
            image_path = "1.jpg"
            sign = infer(image_path)
            #调用 infer 函数，可能是用于对图像进行推断，获取识别到的标志信息。
            #根据识别到的标志信息设置车辆速度 vel                                   infer函数在detect.py中
            if 'crossing' in sign:
                vel=1535
            elif 'limit_10' in sign:
                vel=1500
            else:
                vel=1545
            
            img = dataset(video)
            #调用 dataset 函数，处理视频图像数据，获取处理后的图像。
            result = exe.run(program=infer_program,feed={feeded_var_names[0]: img},fetch_list=target_var)
            #在加载的推理模型上运行推理，获取角度的预测结果。
            angle = result[0][0][0]
            print(result)
            a = int(angle)-35
            #execfile('//home//deep//paddlepaddle//pd_6//test.py')
            lib.send_cmd(vel, a)
            #调用共享库中的 send_cmd 函数，发送命令控制车辆，其中包括速度和角度。
            print(cout) #cout是计数器
            cout=cout+1
            print("angle: %d, throttle: %d" % (a, vel))

    except:
        print('error')
    finally:
    #finally:：在任何情况下都会执行的代码块
        lib.send_cmd(1500, 1500)    #最终发送命令，将车辆速度和角度设置为默认值。


